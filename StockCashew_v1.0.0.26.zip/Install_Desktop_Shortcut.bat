@echo off
echo ===================================================
echo   Creating Desktop Shortcut for Cashew Stock System
echo ===================================================
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\Stock Cashew Management.lnk'); $s.TargetPath = '%~dp0LOAN SYSTEM.exe'; $s.WorkingDirectory = '%~dp0'; $s.IconLocation = '%~dp0bank.ico'; $s.Save()"
echo.
echo [OK] Done! You can now start the application from your Desktop.
echo ===================================================
pause